import SurveyMonkey from './src/survey_monkey';

export default SurveyMonkey;
